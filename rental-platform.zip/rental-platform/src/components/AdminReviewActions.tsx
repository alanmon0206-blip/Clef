"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function AdminReviewActions({ tenantProfileId }: { tenantProfileId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function review(decision: "VERIFIED" | "REJECTED") {
    setLoading(true);
    await fetch(`/api/admin/tenants/${tenantProfileId}/review`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ decision }),
    });
    setLoading(false);
    router.refresh();
  }

  return (
    <div className="flex gap-2">
      <button
        disabled={loading}
        onClick={() => review("VERIFIED")}
        className="text-sm px-4 py-2 rounded-full bg-sauge text-white"
      >
        Valider
      </button>
      <button
        disabled={loading}
        onClick={() => review("REJECTED")}
        className="text-sm px-4 py-2 rounded-full bg-brique text-white"
      >
        Refuser
      </button>
    </div>
  );
}
