/**
 * Élément signature de la plateforme : une jauge horizontale qui traduit
 * la règle "loyer ≈ 33% des revenus" en repère visuel, avec un curseur
 * indiquant où se situe le loyer de l'annonce par rapport à la capacité
 * du locataire. Utilisée sur les cartes d'annonces et les dashboards.
 */
export function SolvencyGauge({
  rentAmount,
  maxRecommendedRent,
  compact = false,
}: {
  rentAmount: number;
  maxRecommendedRent: number;
  compact?: boolean;
}) {
  const ratio = maxRecommendedRent > 0 ? rentAmount / maxRecommendedRent : 1;
  const pct = Math.min(ratio, 1.3) * 100; // capé visuellement à 130%
  const overBudget = ratio > 1.1;
  const tight = ratio > 0.9 && ratio <= 1.1;

  const barColor = overBudget ? "bg-brique" : tight ? "bg-laiton" : "bg-sauge";
  const label = overBudget
    ? "Hors budget estimé"
    : tight ? "À la limite du budget"
    : "Dans votre budget";

  return (
    <div className={compact ? "w-full" : "w-full max-w-xs"}>
      <div className="flex items-baseline justify-between mb-1">
        <span className="text-xs uppercase tracking-wide text-ardoise/60">{label}</span>
        <span className="font-num text-xs text-ardoise/70">
          {Math.round(ratio * 100)}%
        </span>
      </div>
      <div className="relative h-2 rounded-full bg-ligne overflow-hidden">
        <div
          className={`absolute inset-y-0 left-0 rounded-full ${barColor}`}
          style={{ width: `${Math.min(pct, 100)}%` }}
        />
        {/* Repère au seuil des 33% (100% de la capacité recommandée) */}
        <div className="absolute inset-y-0 left-[76.9%] w-px bg-ardoise/40" />
      </div>
    </div>
  );
}
