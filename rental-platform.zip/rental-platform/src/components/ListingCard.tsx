import Link from "next/link";
import { SolvencyGauge } from "./SolvencyGauge";

export function ListingCard({
  listing,
  maxRecommendedRent,
  locked = false,
}: {
  listing: {
    id: string;
    title: string;
    city: string;
    rentAmount: number;
    surfaceM2: number;
    rooms: number;
    photos?: { url: string }[];
  };
  maxRecommendedRent?: number;
  locked?: boolean;
}) {
  const photo = listing.photos?.[0]?.url;

  return (
    <Link
      href={locked ? "/tenant/subscription" : `/listings/${listing.id}`}
      className="block rounded-2xl border border-ligne bg-white overflow-hidden hover:shadow-md transition-shadow relative"
    >
      <div className="h-40 bg-ligne relative">
        {photo ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={photo} alt={listing.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-ardoise/40 font-display">
            Clef
          </div>
        )}
        {locked && (
          <div className="absolute inset-0 bg-ardoise/60 backdrop-blur-sm flex items-center justify-center text-brume text-sm text-center px-4">
            Abonnement requis pour voir les détails
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-display text-lg text-ardoise leading-tight">{listing.title}</h3>
        <p className="text-sm text-ardoise/60 mb-2">
          {listing.city} · {listing.rooms} pièce{listing.rooms > 1 ? "s" : ""} · {listing.surfaceM2} m²
        </p>
        <p className="font-num text-xl text-ardoise mb-3">
          {listing.rentAmount} € <span className="text-sm text-ardoise/50">/ mois</span>
        </p>
        {maxRecommendedRent !== undefined && (
          <SolvencyGauge rentAmount={listing.rentAmount} maxRecommendedRent={maxRecommendedRent} compact />
        )}
      </div>
    </Link>
  );
}
