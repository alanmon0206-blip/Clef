"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function ApplicationActions({ applicationId }: { applicationId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function updateStatus(status: "SHORTLISTED" | "ACCEPTED" | "REJECTED") {
    setLoading(true);
    await fetch(`/api/applications/${applicationId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    setLoading(false);
    router.refresh();
  }

  return (
    <div className="flex gap-2">
      <button
        disabled={loading}
        onClick={() => updateStatus("SHORTLISTED")}
        className="text-xs px-3 py-1.5 rounded-full border border-ligne text-ardoise/70 hover:border-laiton"
      >
        Présélectionner
      </button>
      <button
        disabled={loading}
        onClick={() => updateStatus("ACCEPTED")}
        className="text-xs px-3 py-1.5 rounded-full bg-sauge text-white"
      >
        Accepter
      </button>
      <button
        disabled={loading}
        onClick={() => updateStatus("REJECTED")}
        className="text-xs px-3 py-1.5 rounded-full bg-brique text-white"
      >
        Refuser
      </button>
    </div>
  );
}
