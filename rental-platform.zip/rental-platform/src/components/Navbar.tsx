"use client";
import Link from "next/link";
import { useSession, signOut } from "next-auth/react";

export function Navbar() {
  const { data: session } = useSession();
  const role = (session?.user as any)?.role;

  return (
    <header className="border-b border-ligne bg-brume/95 backdrop-blur sticky top-0 z-30">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="font-display text-xl text-ardoise">
          Clef<span className="text-laiton">·</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm text-ardoise/80">
          <Link href="/listings">Annonces</Link>
          {role === "TENANT" && <Link href="/tenant/dashboard">Mon dossier</Link>}
          {role === "OWNER" && <Link href="/owner/dashboard">Mes annonces</Link>}
          {role === "ADMIN" && <Link href="/admin/dashboard">Administration</Link>}
        </nav>

        <div className="flex items-center gap-3">
          {session ? (
            <button
              onClick={() => signOut({ callbackUrl: "/" })}
              className="text-sm text-ardoise/70 hover:text-ardoise"
            >
              Déconnexion
            </button>
          ) : (
            <>
              <Link href="/login" className="text-sm text-ardoise/80">
                Connexion
              </Link>
              <Link
                href="/register"
                className="text-sm px-4 py-2 rounded-full bg-ardoise text-brume hover:bg-laiton transition-colors"
              >
                Créer un compte
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
