"use client";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export function ApplyButton({ listingId }: { listingId: string }) {
  const { data: session } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const role = (session?.user as any)?.role;

  async function handleApply() {
    if (!session) {
      router.push("/login");
      return;
    }
    setLoading(true);
    setFeedback(null);
    const res = await fetch("/api/applications", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ listingId }),
    });
    const data = await res.json();
    setLoading(false);
    setFeedback(res.ok ? "Candidature envoyée." : data.error);
  }

  if (session && role !== "TENANT") return null;

  return (
    <div>
      <button
        onClick={handleApply}
        disabled={loading}
        className="w-full py-3 rounded-full bg-ardoise text-brume font-medium hover:bg-laiton transition-colors disabled:opacity-50"
      >
        {loading ? "Envoi..." : "Candidater"}
      </button>
      {feedback && <p className="text-sm mt-2 text-ardoise/70">{feedback}</p>}
    </div>
  );
}
