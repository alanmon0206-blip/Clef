/**
 * Moteur d'éligibilité / score de solvabilité.
 *
 * Règle de base du marché locatif français : le loyer (charges comprises)
 * ne devrait pas dépasser ~33% des revenus nets du foyer. On ne l'applique
 * pas de façon binaire : on calcule un SCORE (0-100) qui module la règle
 * selon le garant, le type de contrat, etc. Le score détermine ensuite le
 * loyer maximum recommandé, utilisé pour filtrer les annonces visibles
 * par le locataire.
 */

export type EmploymentType =
  | "CDI"
  | "CDD"
  | "FREELANCE"
  | "STUDENT"
  | "UNEMPLOYED"
  | "RETIRED"
  | "OTHER";

export interface EligibilityInput {
  monthlyNetIncome: number;
  employmentType: EmploymentType;
  hasGuarantor: boolean;
  guarantorIncome?: number | null;
}

export interface EligibilityResult {
  solvencyScore: number; // 0-100
  maxRecommendedRent: number; // en euros
  effectiveIncome: number; // revenu "pondéré" utilisé pour le calcul
  breakdown: {
    baseRatioRent: number; // loyer max selon règle stricte des 33%
    employmentMultiplier: number;
    guarantorBonus: number;
  };
}

const RENT_TO_INCOME_RATIO = 0.33;

// Stabilité de l'emploi -> multiplicateur appliqué au revenu "effectif"
// (un CDI pèse plus qu'un freelance à revenu déclaré égal, etc.)
const EMPLOYMENT_MULTIPLIER: Record<EmploymentType, number> = {
  CDI: 1.0,
  RETIRED: 1.0,
  CDD: 0.9,
  FREELANCE: 0.8,
  STUDENT: 0.6,
  OTHER: 0.75,
  UNEMPLOYED: 0.3,
};

export function computeEligibility(input: EligibilityInput): EligibilityResult {
  const income = Math.max(0, input.monthlyNetIncome);
  const multiplier = EMPLOYMENT_MULTIPLIER[input.employmentType] ?? 0.7;

  // Bonus de garant : on ajoute une fraction du revenu du garant au revenu
  // "effectif" pris en compte (plafonné pour éviter les abus).
  let guarantorBonus = 0;
  if (input.hasGuarantor && input.guarantorIncome) {
    guarantorBonus = Math.min(input.guarantorIncome * 0.5, income * 0.6);
  }

  const effectiveIncome = income * multiplier + guarantorBonus;

  const baseRatioRent = income * RENT_TO_INCOME_RATIO;
  const maxRecommendedRent = Math.round(effectiveIncome * RENT_TO_INCOME_RATIO);

  // Score 0-100 : on normalise le rapport effectiveIncome / income (capé à 1.5x)
  // en une note lisible, avec un plancher pour les revenus insuffisants.
  const ratio = income > 0 ? effectiveIncome / income : 0;
  let score = Math.round(Math.min(ratio, 1.5) / 1.5 * 100);

  if (income <= 0) score = 0;
  if (input.employmentType === "UNEMPLOYED" && !input.hasGuarantor) {
    score = Math.min(score, 20);
  }

  score = Math.max(0, Math.min(100, score));

  return {
    solvencyScore: score,
    maxRecommendedRent,
    effectiveIncome: Math.round(effectiveIncome),
    breakdown: {
      baseRatioRent: Math.round(baseRatioRent),
      employmentMultiplier: multiplier,
      guarantorBonus: Math.round(guarantorBonus),
    },
  };
}

/**
 * Un locataire peut voir/candidater à une annonce si son loyer max
 * recommandé couvre le loyer de l'annonce, avec une marge de flexibilité
 * de 10% pour ne pas être trop restrictif (le score reste visible au
 * propriétaire pour qu'il juge lui-même).
 */
export function isListingVisibleForTenant(
  rentAmount: number,
  maxRecommendedRent: number,
  flexibilityMargin = 0.1
): boolean {
  return rentAmount <= maxRecommendedRent * (1 + flexibilityMargin);
}
