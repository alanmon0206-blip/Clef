import Stripe from "stripe";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
  apiVersion: "2024-06-20",
});

export const TENANT_SUB_PRICE_ID = process.env.STRIPE_PRICE_ID_TENANT_SUB as string;
