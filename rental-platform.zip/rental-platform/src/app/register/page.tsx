"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function RegisterPage() {
  const router = useRouter();
  const [role, setRole] = useState<"TENANT" | "OWNER">("TENANT");
  const [form, setForm] = useState({
    email: "",
    password: "",
    firstName: "",
    lastName: "",
    monthlyNetIncome: "",
    employmentType: "CDI",
    hasGuarantor: false,
    guarantorIncome: "",
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const payload: any = {
      email: form.email,
      password: form.password,
      firstName: form.firstName,
      lastName: form.lastName,
      role,
    };
    if (role === "TENANT") {
      payload.monthlyNetIncome = Number(form.monthlyNetIncome || 0);
      payload.employmentType = form.employmentType;
      payload.hasGuarantor = form.hasGuarantor;
      payload.guarantorIncome = form.guarantorIncome ? Number(form.guarantorIncome) : undefined;
    }

    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setLoading(false);

    if (!res.ok) {
      const data = await res.json();
      setError(data.error?.formErrors?.[0] ?? data.error ?? "Erreur lors de l'inscription.");
      return;
    }
    router.push("/login");
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-16">
      <h1 className="font-display text-3xl text-ardoise mb-2">Créer un compte</h1>
      <p className="text-ardoise/60 mb-8">
        Locataire : constituez votre dossier. Propriétaire : publiez gratuitement.
      </p>

      <div className="flex gap-2 mb-8">
        {(["TENANT", "OWNER"] as const).map((r) => (
          <button
            key={r}
            onClick={() => setRole(r)}
            className={`px-4 py-2 rounded-full text-sm border ${
              role === r ? "bg-ardoise text-brume border-ardoise" : "border-ligne text-ardoise/70"
            }`}
          >
            {r === "TENANT" ? "Je cherche un logement" : "Je propose un logement"}
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <input
            placeholder="Prénom"
            required
            value={form.firstName}
            onChange={(e) => setForm({ ...form, firstName: e.target.value })}
            className="rounded-lg border border-ligne px-3 py-2 bg-white"
          />
          <input
            placeholder="Nom"
            required
            value={form.lastName}
            onChange={(e) => setForm({ ...form, lastName: e.target.value })}
            className="rounded-lg border border-ligne px-3 py-2 bg-white"
          />
        </div>
        <input
          type="email"
          placeholder="Email"
          required
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="w-full rounded-lg border border-ligne px-3 py-2 bg-white"
        />
        <input
          type="password"
          placeholder="Mot de passe (8 caractères min.)"
          required
          minLength={8}
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          className="w-full rounded-lg border border-ligne px-3 py-2 bg-white"
        />

        {role === "TENANT" && (
          <div className="pt-4 border-t border-ligne space-y-4">
            <p className="text-sm font-medium text-ardoise/80">Votre situation</p>
            <select
              value={form.employmentType}
              onChange={(e) => setForm({ ...form, employmentType: e.target.value })}
              className="w-full rounded-lg border border-ligne px-3 py-2 bg-white"
            >
              <option value="CDI">CDI</option>
              <option value="CDD">CDD</option>
              <option value="FREELANCE">Freelance / indépendant</option>
              <option value="STUDENT">Étudiant</option>
              <option value="RETIRED">Retraité</option>
              <option value="UNEMPLOYED">Sans emploi</option>
              <option value="OTHER">Autre</option>
            </select>
            <input
              type="number"
              placeholder="Revenu net mensuel (€)"
              required
              value={form.monthlyNetIncome}
              onChange={(e) => setForm({ ...form, monthlyNetIncome: e.target.value })}
              className="w-full rounded-lg border border-ligne px-3 py-2 bg-white"
            />
            <label className="flex items-center gap-2 text-sm text-ardoise/70">
              <input
                type="checkbox"
                checked={form.hasGuarantor}
                onChange={(e) => setForm({ ...form, hasGuarantor: e.target.checked })}
              />
              J'ai un garant
            </label>
            {form.hasGuarantor && (
              <input
                type="number"
                placeholder="Revenu net mensuel du garant (€)"
                value={form.guarantorIncome}
                onChange={(e) => setForm({ ...form, guarantorIncome: e.target.value })}
                className="w-full rounded-lg border border-ligne px-3 py-2 bg-white"
              />
            )}
            <p className="text-xs text-ardoise/50">
              Vous pourrez ajouter vos justificatifs (fiches de paie, avis d'imposition...) juste
              après l'inscription. Votre dossier sera vérifié avant de pouvoir candidater.
            </p>
          </div>
        )}

        {error && <p className="text-brique text-sm">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 rounded-full bg-ardoise text-brume font-medium hover:bg-laiton transition-colors disabled:opacity-50"
        >
          {loading ? "Création..." : "Créer mon compte"}
        </button>
      </form>
    </div>
  );
}
