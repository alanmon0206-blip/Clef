"use client";
import { useState } from "react";
import { useSearchParams } from "next/navigation";

export default function SubscriptionPage() {
  const params = useSearchParams();
  const status = params.get("status");
  const [loading, setLoading] = useState(false);

  async function startCheckout() {
    setLoading(true);
    const res = await fetch("/api/stripe/checkout", { method: "POST" });
    const data = await res.json();
    setLoading(false);
    if (data.url) window.location.href = data.url;
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-16 text-center">
      <h1 className="font-display text-3xl text-ardoise mb-4">Abonnement locataire</h1>
      <p className="text-ardoise/60 mb-8">
        17€ pour 3 mois d'accès aux candidatures. Renouvelable manuellement, sans engagement.
      </p>

      {status === "success" && (
        <p className="mb-6 text-sauge">
          Paiement reçu. Votre abonnement sera actif dans quelques instants.
        </p>
      )}
      {status === "canceled" && (
        <p className="mb-6 text-brique">Paiement annulé. Vous pouvez réessayer.</p>
      )}

      <div className="rounded-2xl bg-white border border-ligne p-8 mb-6">
        <p className="font-num text-4xl text-ardoise mb-2">17 €</p>
        <p className="text-ardoise/50 text-sm mb-6">/ 3 mois</p>
        <ul className="text-sm text-ardoise/70 space-y-2 text-left mb-6">
          <li>— Candidatures illimitées pendant 3 mois</li>
          <li>— Accès aux annonces filtrées selon votre budget</li>
          <li>— Messagerie avec les propriétaires</li>
        </ul>
        <button
          onClick={startCheckout}
          disabled={loading}
          className="w-full py-3 rounded-full bg-ardoise text-brume font-medium hover:bg-laiton transition-colors disabled:opacity-50"
        >
          {loading ? "Redirection..." : "Payer avec Stripe"}
        </button>
      </div>
    </div>
  );
}
