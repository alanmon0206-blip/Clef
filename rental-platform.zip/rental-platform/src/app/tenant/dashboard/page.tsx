import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { isListingVisibleForTenant } from "@/lib/eligibility";
import { ListingCard } from "@/components/ListingCard";
import { SolvencyGauge } from "@/components/SolvencyGauge";
import Link from "next/link";

export default async function TenantDashboard() {
  const session = await getServerSession(authOptions);
  const userId = (session!.user as any).id;

  const tenantProfile = await prisma.tenantProfile.findUnique({
    where: { userId },
    include: {
      subscriptions: { orderBy: { createdAt: "desc" }, take: 1 },
      applications: { include: { listing: true } },
    },
  });
  if (!tenantProfile) return null;

  const activeSub = tenantProfile.subscriptions[0]?.status === "ACTIVE"
    && tenantProfile.subscriptions[0].endDate! > new Date();

  const listings = await prisma.listing.findMany({
    where: { status: "PUBLISHED" },
    include: { photos: true },
    orderBy: { createdAt: "desc" },
    take: 9,
  });
  const eligible = listings.filter((l) =>
    isListingVisibleForTenant(Number(l.rentAmount), Number(tenantProfile.maxRecommendedRent))
  );

  const statusLabel: Record<string, string> = {
    PENDING: "Dossier en attente de vérification",
    VERIFIED: "Dossier vérifié",
    REJECTED: "Dossier refusé",
    SUSPENDED: "Compte suspendu",
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-10 space-y-10">
      <section className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-1 rounded-2xl bg-white border border-ligne p-6">
          <p className="text-xs uppercase tracking-wide text-ardoise/50 mb-2">Statut du dossier</p>
          <p
            className={`font-medium mb-4 ${
              tenantProfile.fileStatus === "VERIFIED" ? "text-sauge" : "text-laiton"
            }`}
          >
            {statusLabel[tenantProfile.fileStatus]}
          </p>

          <p className="text-xs uppercase tracking-wide text-ardoise/50 mb-2">Score de solvabilité</p>
          <p className="font-num text-3xl text-ardoise mb-4">{tenantProfile.solvencyScore}/100</p>

          <p className="text-xs uppercase tracking-wide text-ardoise/50 mb-2">
            Loyer max recommandé
          </p>
          <p className="font-num text-2xl text-ardoise mb-1">
            {Number(tenantProfile.maxRecommendedRent)} €
          </p>
          <SolvencyGauge
            rentAmount={Number(tenantProfile.maxRecommendedRent)}
            maxRecommendedRent={Number(tenantProfile.maxRecommendedRent)}
            compact
          />

          {!activeSub && (
            <Link
              href="/tenant/subscription"
              className="block mt-6 text-center py-2.5 rounded-full bg-laiton text-brume font-medium"
            >
              S'abonner (17€ / 3 mois)
            </Link>
          )}
        </div>

        <div className="md:col-span-2 rounded-2xl bg-white border border-ligne p-6">
          <p className="text-xs uppercase tracking-wide text-ardoise/50 mb-4">
            Mes candidatures ({tenantProfile.applications.length})
          </p>
          {tenantProfile.applications.length === 0 ? (
            <p className="text-ardoise/50 text-sm">
              Vous n'avez pas encore candidaté. Parcourez les annonces ci-dessous.
            </p>
          ) : (
            <ul className="space-y-3">
              {tenantProfile.applications.map((a) => (
                <li
                  key={a.id}
                  className="flex items-center justify-between text-sm border-b border-ligne pb-3 last:border-0"
                >
                  <span className="text-ardoise">{a.listing.title}</span>
                  <span className="font-num text-xs px-2 py-1 rounded-full bg-brume text-ardoise/70">
                    {a.status}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      <section>
        <h2 className="font-display text-2xl text-ardoise mb-4">
          Logements à votre portée ({eligible.length})
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          {eligible.map((l) => (
            <ListingCard
              key={l.id}
              listing={l}
              maxRecommendedRent={Number(tenantProfile.maxRecommendedRent)}
              locked={!activeSub || tenantProfile.fileStatus !== "VERIFIED"}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
