import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { ApplicationActions } from "@/components/ApplicationActions";

export default async function OwnerDashboard() {
  const session = await getServerSession(authOptions);
  const userId = (session!.user as any).id;

  const ownerProfile = await prisma.ownerProfile.findUnique({
    where: { userId },
    include: {
      listings: {
        include: { applications: { include: { tenantProfile: { include: { user: true } } } } },
        orderBy: { createdAt: "desc" },
      },
    },
  });
  if (!ownerProfile) return null;

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display text-3xl text-ardoise">Mes annonces</h1>
        <Link
          href="/owner/listings/new"
          className="px-5 py-2.5 rounded-full bg-ardoise text-brume font-medium hover:bg-laiton transition-colors"
        >
          Publier une annonce
        </Link>
      </div>

      <div className="space-y-8">
        {ownerProfile.listings.map((listing) => (
          <div key={listing.id} className="rounded-2xl bg-white border border-ligne p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="font-display text-xl text-ardoise">{listing.title}</h2>
                <p className="text-ardoise/50 text-sm">
                  {listing.city} · {Number(listing.rentAmount)} € / mois · {listing.status}
                </p>
              </div>
              <span className="font-num text-xs px-3 py-1.5 rounded-full bg-brume text-ardoise/70">
                {listing.applications.length} candidature(s)
              </span>
            </div>

            <ul className="divide-y divide-ligne">
              {listing.applications.map((app) => (
                <li key={app.id} className="flex items-center justify-between py-3 text-sm">
                  <div>
                    <p className="text-ardoise font-medium">
                      {app.tenantProfile.user.firstName} {app.tenantProfile.user.lastName}
                    </p>
                    <p className="text-ardoise/50 font-num text-xs">
                      Score : {app.scoreAtApplication}/100 · Statut : {app.status}
                    </p>
                  </div>
                  <ApplicationActions applicationId={app.id} />
                </li>
              ))}
              {listing.applications.length === 0 && (
                <li className="py-3 text-sm text-ardoise/40">Aucune candidature pour l'instant.</li>
              )}
            </ul>
          </div>
        ))}
        {ownerProfile.listings.length === 0 && (
          <p className="text-ardoise/50">Vous n'avez pas encore publié d'annonce.</p>
        )}
      </div>
    </div>
  );
}

