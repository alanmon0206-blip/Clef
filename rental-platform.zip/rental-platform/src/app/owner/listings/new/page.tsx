"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewListingPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    title: "",
    description: "",
    rentAmount: "",
    charges: "0",
    surfaceM2: "",
    rooms: "1",
    city: "",
    postalCode: "",
    address: "",
  });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const res = await fetch("/api/listings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        rentAmount: Number(form.rentAmount),
        charges: Number(form.charges),
        surfaceM2: Number(form.surfaceM2),
        rooms: Number(form.rooms),
        photos: [],
      }),
    });
    setLoading(false);

    if (!res.ok) {
      const data = await res.json();
      setError(data.error?.formErrors?.[0] ?? "Erreur lors de la création de l'annonce.");
      return;
    }
    router.push("/owner/dashboard");
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-16">
      <h1 className="font-display text-3xl text-ardoise mb-8">Publier une annonce</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          placeholder="Titre de l'annonce"
          required
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          className="w-full rounded-lg border border-ligne px-3 py-2 bg-white"
        />
        <textarea
          placeholder="Description"
          required
          rows={4}
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          className="w-full rounded-lg border border-ligne px-3 py-2 bg-white"
        />
        <div className="grid grid-cols-2 gap-4">
          <input
            type="number"
            placeholder="Loyer (€, charges comprises)"
            required
            value={form.rentAmount}
            onChange={(e) => setForm({ ...form, rentAmount: e.target.value })}
            className="rounded-lg border border-ligne px-3 py-2 bg-white"
          />
          <input
            type="number"
            placeholder="Charges (€)"
            value={form.charges}
            onChange={(e) => setForm({ ...form, charges: e.target.value })}
            className="rounded-lg border border-ligne px-3 py-2 bg-white"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <input
            type="number"
            placeholder="Surface (m²)"
            required
            value={form.surfaceM2}
            onChange={(e) => setForm({ ...form, surfaceM2: e.target.value })}
            className="rounded-lg border border-ligne px-3 py-2 bg-white"
          />
          <input
            type="number"
            placeholder="Nombre de pièces"
            required
            value={form.rooms}
            onChange={(e) => setForm({ ...form, rooms: e.target.value })}
            className="rounded-lg border border-ligne px-3 py-2 bg-white"
          />
        </div>
        <input
          placeholder="Ville"
          required
          value={form.city}
          onChange={(e) => setForm({ ...form, city: e.target.value })}
          className="w-full rounded-lg border border-ligne px-3 py-2 bg-white"
        />
        <div className="grid grid-cols-2 gap-4">
          <input
            placeholder="Code postal"
            required
            value={form.postalCode}
            onChange={(e) => setForm({ ...form, postalCode: e.target.value })}
            className="rounded-lg border border-ligne px-3 py-2 bg-white"
          />
          <input
            placeholder="Adresse"
            required
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
            className="rounded-lg border border-ligne px-3 py-2 bg-white"
          />
        </div>

        {error && <p className="text-brique text-sm">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 rounded-full bg-ardoise text-brume font-medium hover:bg-laiton transition-colors disabled:opacity-50"
        >
          {loading ? "Publication..." : "Publier gratuitement"}
        </button>
      </form>
    </div>
  );
}
