import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { ApplyButton } from "@/components/ApplyButton";

export default async function ListingDetailPage({ params }: { params: { id: string } }) {
  const listing = await prisma.listing.findUnique({
    where: { id: params.id },
    include: { photos: true, ownerProfile: { include: { user: true } } },
  });
  if (!listing) return notFound();

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <div className="h-72 rounded-2xl bg-ligne overflow-hidden mb-8">
        {listing.photos[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={listing.photos[0].url} alt={listing.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center font-display text-ardoise/40">
            Clef
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-3 gap-10">
        <div className="md:col-span-2">
          <h1 className="font-display text-3xl text-ardoise mb-2">{listing.title}</h1>
          <p className="text-ardoise/50 mb-6">
            {listing.address}, {listing.postalCode} {listing.city}
          </p>
          <p className="text-ardoise/80 leading-relaxed whitespace-pre-line">{listing.description}</p>
        </div>

        <div className="rounded-2xl bg-white border border-ligne p-6 h-fit space-y-4">
          <p className="font-num text-3xl text-ardoise">{Number(listing.rentAmount)} €</p>
          <p className="text-ardoise/50 text-sm">
            + {Number(listing.charges)} € de charges · {listing.surfaceM2} m² · {listing.rooms} pièce(s)
          </p>
          <p className="text-sm text-ardoise/60 pt-2 border-t border-ligne">
            Publié par {listing.ownerProfile.user.firstName}
          </p>
          <ApplyButton listingId={listing.id} />
        </div>
      </div>
    </div>
  );
}
