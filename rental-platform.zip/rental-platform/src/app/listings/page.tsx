import { prisma } from "@/lib/prisma";
import { ListingCard } from "@/components/ListingCard";

export default async function ListingsPage() {
  const listings = await prisma.listing.findMany({
    where: { status: "PUBLISHED" },
    include: { photos: true },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="font-display text-3xl text-ardoise mb-8">Toutes les annonces</h1>
      <div className="grid md:grid-cols-3 gap-6">
        {listings.map((l) => (
          <ListingCard key={l.id} listing={l} />
        ))}
      </div>
      {listings.length === 0 && (
        <p className="text-ardoise/50">Aucune annonce publiée pour le moment.</p>
      )}
    </div>
  );
}
