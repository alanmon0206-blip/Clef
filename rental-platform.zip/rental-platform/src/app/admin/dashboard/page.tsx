import { prisma } from "@/lib/prisma";
import { AdminReviewActions } from "@/components/AdminReviewActions";

export default async function AdminDashboard() {
  const pendingTenants = await prisma.tenantProfile.findMany({
    where: { fileStatus: "PENDING" },
    include: { user: true, documents: true },
    orderBy: { createdAt: "asc" },
  });

  const stats = await prisma.$transaction([
    prisma.user.count({ where: { role: "TENANT" } }),
    prisma.user.count({ where: { role: "OWNER" } }),
    prisma.listing.count({ where: { status: "PUBLISHED" } }),
    prisma.subscription.count({ where: { status: "ACTIVE" } }),
  ]);

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="font-display text-3xl text-ardoise mb-8">Administration</h1>

      <div className="grid grid-cols-4 gap-4 mb-10">
        {[
          ["Locataires", stats[0]],
          ["Propriétaires", stats[1]],
          ["Annonces actives", stats[2]],
          ["Abonnements actifs", stats[3]],
        ].map(([label, value]) => (
          <div key={label as string} className="rounded-2xl bg-white border border-ligne p-5">
            <p className="text-xs uppercase text-ardoise/50 mb-1">{label}</p>
            <p className="font-num text-2xl text-ardoise">{value}</p>
          </div>
        ))}
      </div>

      <h2 className="font-display text-xl text-ardoise mb-4">
        Dossiers en attente de vérification ({pendingTenants.length})
      </h2>
      <div className="space-y-4">
        {pendingTenants.map((t) => (
          <div key={t.id} className="rounded-2xl bg-white border border-ligne p-6 flex items-center justify-between">
            <div>
              <p className="font-medium text-ardoise">
                {t.user.firstName} {t.user.lastName} · {t.user.email}
              </p>
              <p className="text-sm text-ardoise/50 font-num">
                Revenu déclaré : {Number(t.monthlyNetIncome)} € · Score : {t.solvencyScore}/100 ·
                {" "}{t.documents.length} document(s) fourni(s)
              </p>
            </div>
            <AdminReviewActions tenantProfileId={t.id} />
          </div>
        ))}
        {pendingTenants.length === 0 && (
          <p className="text-ardoise/50">Aucun dossier en attente.</p>
        )}
      </div>
    </div>
  );
}
