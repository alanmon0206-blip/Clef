import Link from "next/link";

export default function HomePage() {
  return (
    <div>
      <section className="max-w-6xl mx-auto px-4 pt-16 pb-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <p className="text-xs uppercase tracking-widest text-laiton mb-4">
            Loyer · Revenus · Confiance
          </p>
          <h1 className="font-display text-5xl leading-[1.05] text-ardoise mb-6">
            Ne candidatez qu'à des logements que vous pouvez vraiment payer.
          </h1>
          <p className="text-ardoise/70 text-lg mb-8 max-w-md">
            Clef vérifie votre dossier une fois, calcule votre budget réel, et ne vous
            montre que les annonces à votre portée. Les propriétaires publient gratuitement.
          </p>
          <div className="flex gap-4">
            <Link
              href="/register"
              className="px-6 py-3 rounded-full bg-ardoise text-brume font-medium hover:bg-laiton transition-colors"
            >
              Créer mon dossier
            </Link>
            <Link
              href="/listings"
              className="px-6 py-3 rounded-full border border-ardoise/20 text-ardoise font-medium hover:border-laiton transition-colors"
            >
              Voir les annonces
            </Link>
          </div>
        </div>

        <div className="rounded-3xl bg-white border border-ligne p-8">
          <p className="text-xs uppercase tracking-wide text-ardoise/50 mb-4">
            Exemple de jauge de solvabilité
          </p>
          <div className="space-y-5 font-num">
            <div className="flex justify-between text-sm text-ardoise/70">
              <span>Revenu net déclaré</span><span>2 100 €</span>
            </div>
            <div className="flex justify-between text-sm text-ardoise/70">
              <span>Loyer max recommandé (33%)</span><span>693 €</span>
            </div>
            <div className="h-2 rounded-full bg-ligne overflow-hidden">
              <div className="h-full w-[77%] bg-sauge rounded-full" />
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-ardoise/50">Annonce consultée : 650 €</span>
              <span className="text-sauge font-medium">Dans le budget</span>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 pb-20 grid md:grid-cols-3 gap-8">
        {[
          {
            title: "Un dossier, une fois",
            body: "Revenus, emploi, garant : votre dossier est vérifié puis réutilisé pour chaque candidature.",
          },
          {
            title: "Un filtrage honnête",
            body: "Vous ne voyez que les logements compatibles avec votre budget réel, calculé sur la règle des 33%.",
          },
          {
            title: "Des annonces gratuites",
            body: "Les propriétaires publient gratuitement et ne reçoivent que des candidatures déjà qualifiées.",
          },
        ].map((f) => (
          <div key={f.title} className="p-6 rounded-2xl border border-ligne bg-white">
            <h3 className="font-display text-xl text-ardoise mb-2">{f.title}</h3>
            <p className="text-ardoise/65 text-sm leading-relaxed">{f.body}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
