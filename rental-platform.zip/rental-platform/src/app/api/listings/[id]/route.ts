import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const listing = await prisma.listing.findUnique({
    where: { id: params.id },
    include: { photos: true, ownerProfile: { include: { user: true } } },
  });
  if (!listing) return NextResponse.json({ error: "Annonce introuvable." }, { status: 404 });
  return NextResponse.json({ listing });
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "OWNER") {
    return NextResponse.json({ error: "Non autorisé." }, { status: 403 });
  }
  const body = await req.json();
  const listing = await prisma.listing.update({
    where: { id: params.id },
    data: body,
  });
  return NextResponse.json({ listing });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "OWNER") {
    return NextResponse.json({ error: "Non autorisé." }, { status: 403 });
  }
  await prisma.listing.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
