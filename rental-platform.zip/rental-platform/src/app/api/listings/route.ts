import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { isListingVisibleForTenant } from "@/lib/eligibility";
import { z } from "zod";

// GET /api/listings — liste des annonces publiées.
// Si l'utilisateur connecté est un locataire, on filtre par éligibilité
// (loyer <= loyer max recommandé + marge de flexibilité).
export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  const { searchParams } = new URL(req.url);
  const city = searchParams.get("city") ?? undefined;

  const listings = await prisma.listing.findMany({
    where: {
      status: "PUBLISHED",
      ...(city ? { city: { equals: city, mode: "insensitive" } } : {}),
    },
    include: { photos: true, ownerProfile: { include: { user: true } } },
    orderBy: { createdAt: "desc" },
  });

  const role = (session?.user as any)?.role;

  if (role === "TENANT") {
    const tenantProfile = await prisma.tenantProfile.findUnique({
      where: { userId: (session!.user as any).id },
    });

    // Dossier non vérifié => aucune annonce visible tant que non validé,
    // ni abonnement actif => on renvoie les annonces avec un flag "locked".
    const activeSub = tenantProfile
      ? await prisma.subscription.findFirst({
          where: {
            tenantProfileId: tenantProfile.id,
            status: "ACTIVE",
            endDate: { gte: new Date() },
          },
        })
      : null;

    const filtered = listings
      .filter((l) =>
        tenantProfile
          ? isListingVisibleForTenant(Number(l.rentAmount), Number(tenantProfile.maxRecommendedRent))
          : true
      )
      .map((l) => ({
        ...l,
        locked: !activeSub || tenantProfile?.fileStatus !== "VERIFIED",
      }));

    return NextResponse.json({ listings: filtered, eligibility: tenantProfile ?? null });
  }

  return NextResponse.json({ listings });
}

const createSchema = z.object({
  title: z.string().min(3),
  description: z.string().min(10),
  rentAmount: z.number().positive(),
  charges: z.number().nonnegative().default(0),
  surfaceM2: z.number().positive(),
  rooms: z.number().int().positive(),
  city: z.string().min(1),
  postalCode: z.string().min(1),
  address: z.string().min(1),
  photos: z.array(z.string().url()).default([]),
});

// POST /api/listings — création d'une annonce (propriétaire uniquement)
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const role = (session?.user as any)?.role;
  if (!session || role !== "OWNER") {
    return NextResponse.json({ error: "Non autorisé." }, { status: 403 });
  }

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const data = parsed.data;

  const ownerProfile = await prisma.ownerProfile.findUnique({
    where: { userId: (session!.user as any).id },
  });
  if (!ownerProfile) {
    return NextResponse.json({ error: "Profil propriétaire introuvable." }, { status: 404 });
  }

  const listing = await prisma.listing.create({
    data: {
      ownerProfileId: ownerProfile.id,
      title: data.title,
      description: data.description,
      rentAmount: data.rentAmount,
      charges: data.charges,
      surfaceM2: data.surfaceM2,
      rooms: data.rooms,
      city: data.city,
      postalCode: data.postalCode,
      address: data.address,
      status: "PUBLISHED",
      photos: { create: data.photos.map((url, i) => ({ url, position: i })) },
    },
    include: { photos: true },
  });

  return NextResponse.json({ listing });
}
