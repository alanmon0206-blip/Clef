import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const schema = z.object({
  receiverId: z.string(),
  content: z.string().min(1),
  listingId: z.string().optional(),
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const message = await prisma.message.create({
    data: {
      senderId: (session.user as any).id,
      receiverId: parsed.data.receiverId,
      content: parsed.data.content,
      listingId: parsed.data.listingId,
    },
  });

  return NextResponse.json({ message });
}

// GET /api/messages?with=<userId> — fil de discussion avec un utilisateur
export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const withUserId = searchParams.get("with");
  const userId = (session.user as any).id;

  const messages = await prisma.message.findMany({
    where: {
      OR: [
        { senderId: userId, receiverId: withUserId ?? undefined },
        { senderId: withUserId ?? undefined, receiverId: userId },
      ],
    },
    orderBy: { createdAt: "asc" },
  });

  return NextResponse.json({ messages });
}
