import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const schema = z.object({
  decision: z.enum(["VERIFIED", "REJECTED"]),
  note: z.string().optional(),
});

// PATCH /api/admin/tenants/[id]/review — [id] = tenantProfileId
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "ADMIN") {
    return NextResponse.json({ error: "Non autorisé." }, { status: 403 });
  }

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const tenantProfile = await prisma.tenantProfile.update({
    where: { id: params.id },
    data: {
      fileStatus: parsed.data.decision,
      fileReviewedAt: new Date(),
      fileReviewNote: parsed.data.note,
    },
  });

  await prisma.user.update({
    where: { id: tenantProfile.userId },
    data: { status: parsed.data.decision === "VERIFIED" ? "VERIFIED" : "REJECTED" },
  });

  await prisma.moderationLog.create({
    data: {
      adminId: (session.user as any).id,
      targetType: "USER",
      targetId: tenantProfile.userId,
      action: parsed.data.decision === "VERIFIED" ? "APPROVE" : "REJECT",
      reason: parsed.data.note,
    },
  });

  return NextResponse.json({ tenantProfile });
}
