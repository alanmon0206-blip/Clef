import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";

// POST /api/stripe/checkout — crée une session de paiement Stripe pour
// l'abonnement locataire (17€ / 3 mois, "one-off" reconductible via un
// Payment Link ou un abonnement Stripe selon la config du Price).
export async function POST() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "TENANT") {
    return NextResponse.json({ error: "Non autorisé." }, { status: 403 });
  }

  const tenantProfile = await prisma.tenantProfile.findUnique({
    where: { userId: (session!.user as any).id },
    include: { user: true },
  });
  if (!tenantProfile) {
    return NextResponse.json({ error: "Dossier locataire introuvable." }, { status: 404 });
  }

  const checkoutSession = await stripe.checkout.sessions.create({
    mode: "payment", // paiement unique de 17€ couvrant 3 mois (renouvellement manuel)
    payment_method_types: ["card"],
    customer_email: tenantProfile.user.email,
    line_items: [
      {
        price_data: {
          currency: "eur",
          product_data: {
            name: "Abonnement locataire — 3 mois",
            description: "Accès aux candidatures pendant 3 mois",
          },
          unit_amount: 1700,
        },
        quantity: 1,
      },
    ],
    metadata: { tenantProfileId: tenantProfile.id },
    success_url: `${process.env.NEXT_PUBLIC_APP_URL}/tenant/subscription?status=success`,
    cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/tenant/subscription?status=canceled`,
  });

  await prisma.subscription.create({
    data: {
      tenantProfileId: tenantProfile.id,
      status: "PENDING_PAYMENT",
      stripeCheckoutId: checkoutSession.id,
    },
  });

  return NextResponse.json({ url: checkoutSession.url });
}
