import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import Stripe from "stripe";

export const config = { api: { bodyParser: false } };

export async function POST(req: Request) {
  const body = await req.text();
  const signature = headers().get("stripe-signature") as string;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET as string
    );
  } catch (err) {
    return NextResponse.json({ error: "Signature invalide." }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const checkoutSession = event.data.object as Stripe.Checkout.Session;
    const tenantProfileId = checkoutSession.metadata?.tenantProfileId;
    if (tenantProfileId) {
      const start = new Date();
      const end = new Date();
      end.setMonth(end.getMonth() + 3);

      await prisma.subscription.updateMany({
        where: { stripeCheckoutId: checkoutSession.id },
        data: {
          status: "ACTIVE",
          startDate: start,
          endDate: end,
          stripeCustomerId:
            typeof checkoutSession.customer === "string" ? checkoutSession.customer : undefined,
        },
      });
    }
  }

  return NextResponse.json({ received: true });
}
