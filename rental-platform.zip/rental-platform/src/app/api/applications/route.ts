import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { isListingVisibleForTenant } from "@/lib/eligibility";
import { z } from "zod";

// POST /api/applications — candidater à une annonce (locataire, vérifié + abonné)
const createSchema = z.object({
  listingId: z.string(),
  message: z.string().optional(),
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "TENANT") {
    return NextResponse.json({ error: "Non autorisé." }, { status: 403 });
  }

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const tenantProfile = await prisma.tenantProfile.findUnique({
    where: { userId: (session!.user as any).id },
  });
  if (!tenantProfile) {
    return NextResponse.json({ error: "Dossier locataire introuvable." }, { status: 404 });
  }
  if (tenantProfile.fileStatus !== "VERIFIED") {
    return NextResponse.json(
      { error: "Votre dossier doit être vérifié avant de candidater." },
      { status: 403 }
    );
  }

  const activeSub = await prisma.subscription.findFirst({
    where: { tenantProfileId: tenantProfile.id, status: "ACTIVE", endDate: { gte: new Date() } },
  });
  if (!activeSub) {
    return NextResponse.json(
      { error: "Un abonnement actif (17€ / 3 mois) est requis pour candidater." },
      { status: 402 }
    );
  }

  const listing = await prisma.listing.findUnique({ where: { id: parsed.data.listingId } });
  if (!listing || listing.status !== "PUBLISHED") {
    return NextResponse.json({ error: "Annonce indisponible." }, { status: 404 });
  }

  if (!isListingVisibleForTenant(Number(listing.rentAmount), Number(tenantProfile.maxRecommendedRent))) {
    return NextResponse.json(
      { error: "Ce logement dépasse votre capacité financière estimée." },
      { status: 403 }
    );
  }

  const application = await prisma.application.upsert({
    where: {
      listingId_tenantProfileId: {
        listingId: listing.id,
        tenantProfileId: tenantProfile.id,
      },
    },
    update: { message: parsed.data.message, status: "PENDING" },
    create: {
      listingId: listing.id,
      tenantProfileId: tenantProfile.id,
      message: parsed.data.message,
      scoreAtApplication: tenantProfile.solvencyScore,
    },
  });

  return NextResponse.json({ application });
}

// GET /api/applications — liste des candidatures (selon rôle)
export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const role = (session.user as any).role;
  const userId = (session.user as any).id;

  if (role === "TENANT") {
    const tenantProfile = await prisma.tenantProfile.findUnique({ where: { userId } });
    const applications = await prisma.application.findMany({
      where: { tenantProfileId: tenantProfile?.id },
      include: { listing: { include: { photos: true } } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ applications });
  }

  if (role === "OWNER") {
    const ownerProfile = await prisma.ownerProfile.findUnique({ where: { userId } });
    const applications = await prisma.application.findMany({
      where: { listing: { ownerProfileId: ownerProfile?.id } },
      include: {
        listing: true,
        tenantProfile: { include: { user: true } },
      },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ applications });
  }

  return NextResponse.json({ error: "Rôle non pris en charge." }, { status: 403 });
}
