import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const schema = z.object({
  status: z.enum(["SHORTLISTED", "ACCEPTED", "REJECTED", "WITHDRAWN"]),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const application = await prisma.application.findUnique({
    where: { id: params.id },
    include: { listing: { include: { ownerProfile: true } } },
  });
  if (!application) return NextResponse.json({ error: "Candidature introuvable." }, { status: 404 });

  const role = (session.user as any).role;
  const userId = (session.user as any).id;

  // Le locataire ne peut que retirer sa propre candidature.
  if (role === "TENANT" && parsed.data.status !== "WITHDRAWN") {
    return NextResponse.json({ error: "Non autorisé." }, { status: 403 });
  }
  if (role === "OWNER" && application.listing.ownerProfile.userId !== userId) {
    return NextResponse.json({ error: "Non autorisé." }, { status: 403 });
  }

  const updated = await prisma.application.update({
    where: { id: params.id },
    data: { status: parsed.data.status },
  });

  // Si acceptée, on marque l'annonce comme louée.
  if (parsed.data.status === "ACCEPTED") {
    await prisma.listing.update({ where: { id: application.listingId }, data: { status: "RENTED" } });
  }

  return NextResponse.json({ application: updated });
}
