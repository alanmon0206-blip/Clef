import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { computeEligibility } from "@/lib/eligibility";

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  role: z.enum(["TENANT", "OWNER"]),
  // champs locataire (optionnels si OWNER)
  monthlyNetIncome: z.number().optional(),
  employmentType: z
    .enum(["CDI", "CDD", "FREELANCE", "STUDENT", "UNEMPLOYED", "RETIRED", "OTHER"])
    .optional(),
  hasGuarantor: z.boolean().optional(),
  guarantorIncome: z.number().optional(),
});

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const data = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email: data.email.toLowerCase() } });
  if (existing) {
    return NextResponse.json({ error: "Un compte existe déjà avec cet email." }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(data.password, 10);

  const user = await prisma.user.create({
    data: {
      email: data.email.toLowerCase(),
      passwordHash,
      firstName: data.firstName,
      lastName: data.lastName,
      role: data.role,
      status: "PENDING",
    },
  });

  if (data.role === "TENANT") {
    const employmentType = data.employmentType ?? "OTHER";
    const monthlyNetIncome = data.monthlyNetIncome ?? 0;
    const hasGuarantor = data.hasGuarantor ?? false;

    const elig = computeEligibility({
      monthlyNetIncome,
      employmentType,
      hasGuarantor,
      guarantorIncome: data.guarantorIncome,
    });

    await prisma.tenantProfile.create({
      data: {
        userId: user.id,
        employmentType,
        monthlyNetIncome,
        hasGuarantor,
        guarantorIncome: data.guarantorIncome,
        solvencyScore: elig.solvencyScore,
        maxRecommendedRent: elig.maxRecommendedRent,
        fileStatus: "PENDING",
      },
    });
  } else {
    await prisma.ownerProfile.create({
      data: { userId: user.id },
    });
  }

  return NextResponse.json({ ok: true, userId: user.id });
}
