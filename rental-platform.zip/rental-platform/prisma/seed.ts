import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { computeEligibility } from "../src/lib/eligibility";

const prisma = new PrismaClient();

async function main() {
  const password = await bcrypt.hash("password123", 10);

  const admin = await prisma.user.upsert({
    where: { email: "admin@clef.fr" },
    update: {},
    create: {
      email: "admin@clef.fr",
      passwordHash: password,
      firstName: "Admin",
      lastName: "Clef",
      role: "ADMIN",
      status: "VERIFIED",
    },
  });

  const ownerUser = await prisma.user.upsert({
    where: { email: "owner@clef.fr" },
    update: {},
    create: {
      email: "owner@clef.fr",
      passwordHash: password,
      firstName: "Camille",
      lastName: "Propriétaire",
      role: "OWNER",
      status: "VERIFIED",
      ownerProfile: { create: {} },
    },
    include: { ownerProfile: true },
  });

  const elig = computeEligibility({
    monthlyNetIncome: 2100,
    employmentType: "CDI",
    hasGuarantor: false,
  });

  const tenantUser = await prisma.user.upsert({
    where: { email: "tenant@clef.fr" },
    update: {},
    create: {
      email: "tenant@clef.fr",
      passwordHash: password,
      firstName: "Sacha",
      lastName: "Locataire",
      role: "TENANT",
      status: "VERIFIED",
      tenantProfile: {
        create: {
          employmentType: "CDI",
          monthlyNetIncome: 2100,
          hasGuarantor: false,
          solvencyScore: elig.solvencyScore,
          maxRecommendedRent: elig.maxRecommendedRent,
          fileStatus: "VERIFIED",
        },
      },
    },
  });

  const ownerProfile = await prisma.ownerProfile.findUnique({ where: { userId: ownerUser.id } });

  await prisma.listing.createMany({
    data: [
      {
        ownerProfileId: ownerProfile!.id,
        title: "Studio lumineux proche centre-ville",
        description: "Studio rénové de 22m², cuisine équipée, idéal étudiant ou jeune actif.",
        rentAmount: 650,
        charges: 40,
        surfaceM2: 22,
        rooms: 1,
        city: "Lyon",
        postalCode: "69003",
        address: "12 rue de la République",
        status: "PUBLISHED",
      },
      {
        ownerProfileId: ownerProfile!.id,
        title: "T3 avec balcon, quartier calme",
        description: "Appartement de 65m², 2 chambres, balcon, parking inclus.",
        rentAmount: 1250,
        charges: 90,
        surfaceM2: 65,
        rooms: 3,
        city: "Lyon",
        postalCode: "69007",
        address: "45 avenue Berthelot",
        status: "PUBLISHED",
      },
    ],
    skipDuplicates: true,
  });

  console.log("Seed terminé.");
  console.log("Comptes de test (mot de passe: password123) :");
  console.log("- Admin:", admin.email);
  console.log("- Propriétaire:", ownerUser.email);
  console.log("- Locataire:", tenantUser.email);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
